/**
 * 
 */
package com.sap.tc.buildplugin.pdef;

import com.sap.tc.buildplugin.scdef.EdenBuildPlugin;
import com.sap.tc.buildplugin.scdef.ScdefGeneratorTask;


/**
 * Anttask for Project definition generation.
 */
public class PdefGeneratorTask extends ScdefGeneratorTask {

    @Override
	protected EdenBuildPlugin getPluginInstance() {
    	return new PdefValidator();
    }
}
