package com.sap.tc.buildplugin.pdefmoin;

import java.io.*;
import java.util.List;

import com.sap.cim.api.admin.*;
import com.sap.cim.api.core.*;
import com.sap.cim.api.security.*;
import com.sap.sld.api.wbem.cim.CIMReference;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.exception.*;

/**
 * Construct a virtual CIMOM, pre-loaded with CIM model
 * to be used to import/export data and to work with SLD Std API instances.
 * @author d024219
 *
 */
public class VirtualCIMOM {

	private WBEMClient wbemclient;
	private ICIMDomainContext domainContext;
	private final ICIMUser user=new AlmightyUser("LM User");
	private final String domainname="LM";

	/**
	 * Construct the virtual CIMOM and load the CIM Model into it
	 * @throws CIMException if virtual CIM domain could not be constructed or if the model could not be loaded.
	 */
	public VirtualCIMOM(InputStream aModelInputStream) throws CIMException
	{

		init(aModelInputStream);

	}

	private void init(InputStream aModelInputStream) throws CIMException
	{

		// create a memory domain for loading the contents
		// create and initialize the EDEN domain
		if(CIMStartup.getStandaloneDomainManager()==null)
			CIMStartup.createStandaloneDomainManager();
		domainContext=CIMStartup.getStandaloneDomainManager().initializeVirtualDomain(domainname,null);

		// start OM
		domainContext.activateObjectManager();
		// get a client for the domain
		wbemclient=domainContext.createWBEMLocalClient(user);
		// load CIM model
		importContent(aModelInputStream);

	}

/**
 * Get WBEMClient to read/write data in this virtual CIMOM
 * @return
 */
	public WBEMClient getWBEMClient()
	{
		return wbemclient;
	}

	/**
	 * Import a CIM data file (content) into this virtual CIMOM
	 *
	 * Note: the model was automatically loaded during construction
	 *
	 * @param importFile File to import (created via SLD export)
	 * @throws CIMException if there are any errors during import
	 */
	public void importContent(InputStream importInputStream)
			throws CIMException
	{
		ICIMImport importControl = domainContext.getImportManager();
		ICIMPreparationStatus preparationStatus = importControl.prepareImport(
				importInputStream, wbemclient.getTargetNamespace(), user);
		if (preparationStatus.isImportCompatible()) {
			// this starts a separate thread
			// TODO suppress Thread warnings in IDE
			importControl.performImport(preparationStatus);
			// wait until import is finished
			try {
				importControl.join();
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
				throw new CIMException("Import interrupted", null, ex);
			}
			ICIMImportStatus importStatus = importControl.getImportStatus();
			if(!importStatus.getErrors().isEmpty())
			{
				throw new CIMException(CIMErrorCodes.CIM_ERR_FAILED,"Errors during import:\n{0}",
						new Object[]{importStatus.getErrors()});
			}
		}
		else
			throw new CIMException(CIMErrorCodes.CIM_ERR_FAILED,"Cannot import CIM data: {0}",new Object[]{
					preparationStatus.getStatusMessage()});
		// now file is imported
	}
	
	/**
	 * Export all CIM data of this domain as a ZIP file on the specified OutputStream
	 * The CIM model is not included. The caller has to close the output stream
	 * @param exportOutputStream stream where to write the export
	 * @throws CIMException in case of problems with retrieving CIM data
	 * @throws IOException in case of problems writing to the output stream
	 */
	public void exportContent(
			OutputStream exportOutputStream, 
			List<CIMReference> referenceList,
			List<String> messages) throws CIMException, IOException {
		ICIMExport exportManager = domainContext.getExportManager();
		exportManager.performSpecialExport(wbemclient.getTargetNamespace(), user, referenceList);
		try {
			exportManager.join();
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt(); // set the interrupt flag again (cleared by exception)
			throw new CIMException("Export interrupted",null,e);
		} // wait until it is finished

		ICIMExportResultItem[] exportResults = exportManager.getStatus().getExportResults();
		byte[] resultBytes = exportResults[0].getResultBytes();
		exportOutputStream.write(resultBytes);
	}
}
