package com.sap.tc.buildplugin.pdefnwproducts;

import java.io.File;

import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;
import javax.xml.transform.stream.StreamSource;

public class UriResolver implements URIResolver {

	private final File	fileToResolve;

	public UriResolver(File stream)
	{
		this.fileToResolve = stream;
	}

	public Source resolve(String href, String base) throws TransformerException
	{
		return new StreamSource(fileToResolve);
	}
//	URL base_path;
//
//	private static final Logger logger = Logger.getLogger("");
//
//	public UriResolver(URL path) {
//		this.base_path = path;
//	}
//
//	public Source resolve(String href, String base) {
//		StringBuffer path = null;
//		if (href.equals("functions.xsl")) {
//			path = new StringBuffer(this.base_path.toString());
//			//path.append(href);
//			logger.info( "path in URIResolver " + path.toString());
//		}
//		String systemID = base_path.toExternalForm(  );
//		if (path != null)
//		{
//			File file = new File(path.toString());
//			if (file.exists())
//				logger.info("\n------------File Path:  "+ file.getAbsolutePath());
//			Source mySrc =  new StreamSource(file);
//			mySrc.setSystemId(systemID);
//			return mySrc;
//		}
//		return null;
//	}
}
