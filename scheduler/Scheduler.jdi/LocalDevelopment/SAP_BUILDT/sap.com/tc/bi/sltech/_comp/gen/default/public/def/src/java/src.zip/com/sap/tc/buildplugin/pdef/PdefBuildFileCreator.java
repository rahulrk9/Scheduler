package com.sap.tc.buildplugin.pdef;

import com.sap.tc.buildplugin.scdef.ScdefBuildFileCreator;


public class PdefBuildFileCreator extends ScdefBuildFileCreator {
	
    @Override
	protected String getGeneratorChainName() {
    	return "sap.com~sl.pdef_chain";
    }
    
}
