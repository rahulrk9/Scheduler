package com.sap.tc.buildplugin.pdefmoin;

import java.io.*;
import java.util.*;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;

import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pdef.PdefValidator;
import com.sap.tc.buildplugin.pdefmoin.checks.VerificationProperties;
import com.sap.tc.buildplugin.pdefnwproducts.JarUtil;
import com.sap.tc.buildplugin.scdef.EdenBuildPluginConstants;
import com.sap.tc.buildplugin.scdef.ScdefDCUtil;
import com.sap.tc.buildplugin.util.BuildPluginException;

public class PdefMoinValidator extends PdefValidator
{

	protected static final String	MOIN_OUTPUT_FILENAME	= "moin2cim.zip";
	private static final String		FUN_DC_MAP_DIR			= "fun-dc-map";

	private final String			classname				= this.getClass().getName();

	private final ArrayList<String>	funDcMapPathes			= new ArrayList<String>();

	// @Override
	// public void execute(EmfTask emfTask, List<File> sourceDirList, List<File> compilePPDirList,
	// File packDir, File tempDir)
	// throws BuildPluginException
	// {
	// // checkMoin(moinAntTask);
	// super.execute(emfTask, sourceDirList, compilePPDirList, packDir, tempDir);
	// }

	@Override
	protected List<String> getInputFilenameList()
	{
		List<String> result = super.getInputFilenameList();
		result.add(EdenBuildPluginConstants.MOIN_INPUT_FILENAME);
		result.add(EdenBuildPluginConstants.NW_PRODUCTS_XSD);
		result.add(EdenBuildPluginConstants.NW_PRODUCTS_EXTEND_XLS);
		result.add(EdenBuildPluginConstants.USAGES_DATA_XLS);
		result.add(EdenBuildPluginConstants.UTDEF_XLS);
		result.add(EdenBuildPluginConstants.FUNCTIONS_XLS);
		result.add(EdenBuildPluginConstants.ADDITIONAL_NODES_XML);
		result.add(EdenBuildPluginConstants.ITSCENARIOS_XSL);
		result.add(EdenBuildPluginConstants.JEXCLUDE_XSL);
		return result;
	}

	@Override
	protected void generate(HashMap<String, File> inputFileMap, File packdir, File tempdir, List<File> sourceDirList, List<File> compilePPDirList)
	throws BuildPluginException, CIMException, IOException
	{
		final String methodName = classname + ".generate";
		loggMethodStart(methodName);
		String moinExportPath = tempdir.getAbsolutePath() + File.separator + MOIN_OUTPUT_FILENAME;
		File moinExportFile = new File(moinExportPath);

		InputStream exportUtilModelInputStream = null;
		InputStream verificationModelInputStream = null;
		try
		{
			exportUtilModelInputStream = getModelInputStream("Import", inputFileMap);
			CIMExportUtil exportUtil = new CIMExportUtil(exportUtilModelInputStream);
			loggMessage("Before MOIN2CIM export creation to: " + moinExportPath);
			File descriptionFile = inputFileMap.get(DESCRIPTION_INPUT_FILENAME);
			if (descriptionFile == null)
			{
				throw new BuildPluginException("No " + DESCRIPTION_INPUT_FILENAME + " file found");
			}
			HashMap<String, String> productNameVersionVendorMap = new HashMap<String, String>();
			readNameVersionVendorFromDescription(productNameVersionVendorMap, descriptionFile);
			String tName = productNameVersionVendorMap.get(MAP_KEY_NAME);
			String tVersion = productNameVersionVendorMap.get(MAP_KEY_VERSION);
			String tVendor = productNameVersionVendorMap.get(MAP_KEY_VENDOR);
			loggMessage(".description content (Name/Version/Vendor): " + tName + "/" + tVersion + "/" + tVendor);

			Hashtable<String, String> properties = new Hashtable<String, String>();
			if (ScdefDCUtil.dcContainsCompleteProductModel())
			{
				properties.put(VerificationProperties.ALL_PRODUCTS, VerificationProperties.ALL_PRODUCTS_YES);
			}
			else
			{
				properties.put(VerificationProperties.ALL_PRODUCTS, VerificationProperties.ALL_PRODUCTS_NO);
				properties.put(VerificationProperties.PRODUCT_NAME, tName);
				properties.put(VerificationProperties.VENDOR, tVersion);
				properties.put(VerificationProperties.VERSION, tVendor);
			}

			// convert moin to cim
			exportUtil.convertMOINToCIM(messages, properties);
			loggMessage("After MOIN2CIM export creation.");

			// the dc contains the complete product model
			// create nw_products.xml and transform it for nw_products_extended.xml, usage_data.xml
			// and utdef.xml
			if (ScdefDCUtil.dcContainsCompleteProductModel() || ScdefDCUtil.generateNwProducts())
			{
				String pathToNwProductsXML = tempdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.NW_PRODUCTS_XML;
				String pathToNwProductsExtendedXML = tempdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.NW_PRODUCTS_EXTEND_XML;
				String pathToUsageDataXML = tempdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.USAGES_DATA_XML;
				String pathToUtdefXML = tempdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.UT_DEF_XML;
				String pathToItscenariosXML = tempdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.ITSCENARIOS_XML;
				String pathToJexcludeXML = tempdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.JEXCLUDE_XML;

				File extendedXSL = inputFileMap.get(EdenBuildPluginConstants.NW_PRODUCTS_EXTEND_XLS);
				File usageDataXSL = inputFileMap.get(EdenBuildPluginConstants.USAGES_DATA_XLS);
				File utedefXSL = inputFileMap.get(EdenBuildPluginConstants.UTDEF_XLS);
				File functionsXSL = inputFileMap.get(EdenBuildPluginConstants.FUNCTIONS_XLS);
				File itscenariosXSL = inputFileMap.get(EdenBuildPluginConstants.ITSCENARIOS_XSL);
				File jexcludeXSL = inputFileMap.get(EdenBuildPluginConstants.JEXCLUDE_XSL);
				File nwProductsXSD = inputFileMap.get(EdenBuildPluginConstants.NW_PRODUCTS_XSD);

				File additionalNodes = inputFileMap.get(EdenBuildPluginConstants.ADDITIONAL_NODES_XML);

				exportUtil.generateXMLFiles(pathToNwProductsXML, pathToNwProductsExtendedXML, pathToUsageDataXML, pathToUtdefXML, pathToItscenariosXML,
						pathToJexcludeXML, extendedXSL, usageDataXSL, utedefXSL, itscenariosXSL, jexcludeXSL, functionsXSL, additionalNodes, messages);

				loggMessage("After creating all xml files.");

				isNwProductsXMLValid(pathToNwProductsXML, nwProductsXSD);

				File utDefFile = new File(tempdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.UT_DEF_XML);
				File tempUtcFile = new File(tempdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.CONTENT_NW_UTC);
				List<File> files = new ArrayList<File>();
				files.add(utDefFile);
				JarUtil.createJarArchiv(tempUtcFile, files);

				loggMessage("After creating " + EdenBuildPluginConstants.CONTENT_NW_UTC);

				File utcFile = new File(packdir.getAbsolutePath() + File.separator + EdenBuildPluginConstants.CONTENT_NW_UTC);

				copyFileToFile(tempUtcFile, utcFile);
				loggFileCopy(EdenBuildPluginConstants.CONTENT_NW_UTC, tempUtcFile, utcFile);
			}

			if (!ScdefDCUtil.dcContainsCompleteProductModel())
			{
				exportUtil.exportCIM(moinExportPath, tName, tVersion, tVendor, messages);
				loggMessage("Substituting " + moinExportPath + " for " + EdenBuildPluginConstants.CR_CONTENT_FILENAME);

				// test exported content
				// modelInputStream.
				try
				{
					verificationModelInputStream = getModelInputStream("Verification", inputFileMap);
					isExportedContentCorrect(moinExportFile, verificationModelInputStream);
				}
				finally
				{
					if (verificationModelInputStream != null)
					{
						verificationModelInputStream.close();
					}
				}
				loggMessage("Exported content " + EdenBuildPluginConstants.CR_CONTENT_FILENAME + " is correct.");

				// Substitute cim export file generated from MOIN output for CR_CONTENT input file
				inputFileMap.put(EdenBuildPluginConstants.CR_CONTENT_FILENAME, moinExportFile);
			}

			// Search for fun-dc-map directory
			File funDcMapSourceDir = null;
			for (File sourceDir : sourceDirList)
			{
				File sourceDirCandidate = new File(sourceDir, FUN_DC_MAP_DIR);
				if (sourceDirCandidate.isDirectory())
				{
					funDcMapSourceDir = sourceDirCandidate;
					loggMessage("Found FUN_DC_MAP_DIR <" + sourceDirCandidate.getAbsolutePath() + "> in sourcedir list");
					break;
				}
			}

			// Create and populate directory in pack area if sourcedir was found
			if (funDcMapSourceDir != null)
			{
				File funDcMapDestDir = new File(packdir, FUN_DC_MAP_DIR);
				if (!funDcMapDestDir.mkdir())
				{
					throw new BuildPluginException("Failed to create FUN_DC_MAP_DIR in packing area");
				}
				// Copy all plain files from funDc sourcedir to funDc packdir
				boolean fileCopied = false;
				for (File inputFile : funDcMapSourceDir.listFiles())
				{
					if (inputFile.isFile())
					{
						String filename = inputFile.getName();
						File outputFile = new File(funDcMapDestDir, filename);
						copyFileToFile(inputFile, outputFile);
						fileCopied = true;
						loggMessage("Copied FUN_DC_MAP_DIR file: " + filename);
						funDcMapPathes.add(FUN_DC_MAP_DIR + "/" + filename);
					}
				}
				if (!fileCopied)
				{
					loggMessage("No files found in FUN_DC_MAP_DIR");
				}
			}
			else
			{
				loggMessage("No FUN_DC_MAP_DIR in sourcedir list");
			}

			super.generate(inputFileMap, packdir, tempdir, sourceDirList, compilePPDirList);
			if (moinExportFile.delete())
			{
				loggMessage("Deleted MOIN export file: " + moinExportFile.getAbsolutePath());
			}
			else
			{
				loggMessage("Failed to delete MOIN export file: " + moinExportFile.getAbsolutePath());
			}
		}
		finally
		{
			if (exportUtilModelInputStream != null)
			{
				exportUtilModelInputStream.close();
			}
		}

		loggMethodEnd(methodName);
	}

	/**
	 * Test if the exported content is correct. This methods try to import the content in new one
	 * virtual CIMOM. If it fails the content is corrupt.
	 * 
	 * @param moinExportFile
	 *            - the exported content file
	 * @param modelInputStream
	 *            - the input stream containing the model
	 * @throws BuildPluginException
	 *             - thrown if the content can not be imported
	 */
	private void isExportedContentCorrect(File moinExportFile, InputStream modelInputStream) throws BuildPluginException
	{
		final String methodName = classname + ".testExportedContent";
		loggMethodStart(methodName);
		try
		{
			VirtualCIMOM testCIMOM = new VirtualCIMOM(modelInputStream);
			testCIMOM.importContent(new FileInputStream(moinExportFile));
		}
		catch (CIMException e)
		{
			loggMessage("Exported content can not be imported");
			// throw new BuildPluginException("Exported content can not be imported.", e);
			Log.warn("Exported content can not be imported", e);
		}
		catch (FileNotFoundException e)
		{
			loggMessage("Exported content file " + EdenBuildPluginConstants.CR_CONTENT_FILENAME + " not found.");
			throw new BuildPluginException("Exported content file " + EdenBuildPluginConstants.CR_CONTENT_FILENAME + " not found.");
		}
		loggMethodEnd(methodName);
	}

	private void isNwProductsXMLValid(String nwProducts, File nwProductsSchema)
	{
		if (nwProductsSchema == null)
		{
			loggMessage("Schema does not exist!");
			return;
		}
		try
		{
			SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
			Schema schema = factory.newSchema(nwProductsSchema);
			Validator validator = schema.newValidator();

			Source source = new StreamSource(nwProducts);
			validator.validate(source);
		}
		catch (SAXException ex)
		{
			loggMessage("nw_products.xml is not valid xml. Reason: " + ex.getMessage());
			Log.warn("nw_products.xml is not valid xml. Reason: " + ex.getMessage());
		}
		catch (IOException e)
		{
			loggMessage("IOException while reading nw_products.xml. Reason: " + e.getMessage());
			Log.warn("IOException while reading nw_products.xml. Reason: " + e.getMessage());
		}

	}

	@Override
	protected ArrayList<String> getFunDcMapPathes()
	{
		return funDcMapPathes;
	}
	// private void checkMoin(EmfTask emfAntTask) {
	//
	// RefPackage myPackage = connection.getPackage("sap.com/lm/slmodel", "slmodel");
	// moinAntTask.log( "got package " + myPackage );
	//
	// QueryScopeProvider queryScopeProvider = new QueryScopeProvider( ) {
	// public boolean isInclusiveScope() {
	// return false;
	// }
	//
	// public CRI[] getContainerScope() {
	// return new CRI[0];
	// }
	//
	// public PRI[] getPartitionScope() {
	// return new PRI[0];
	// }
	// };
	//
	// MQLResultSet componentsSet = null;
	//
	// componentsSet = connection.getMQLProcessor().execute(
	//						"select pSFe from slmodel::ProductShipsFunctionalElement as pSFe", queryScopeProvider); //$NON-NLS-1$
	//
	//				RefObject[] components = componentsSet.getRefObjects("pSFe"); //$NON-NLS-1$
	//
	// boolean noComponentsFound = true;
	// for (int i = 0; i < components.length; i++) {
	// noComponentsFound = false;
	// // log( "got component: " + components[i] );
	// ProductShipsFunctionalElement element = (ProductShipsFunctionalElement) components[i];
	// Product groupComponent = element.getGroupComponent();
	// moinAntTask.log( "got product: " + groupComponent.getCaption() );
	// if (i == 2) {
	// int checked = i + 1;
	// moinAntTask.log( "finishing MOIN check after " + checked + " components");
	// break;
	// }
	// }
	//
	// if (noComponentsFound) {
	// moinAntTask.log("didn't find any MOIN components");
	// }
	// }

}
