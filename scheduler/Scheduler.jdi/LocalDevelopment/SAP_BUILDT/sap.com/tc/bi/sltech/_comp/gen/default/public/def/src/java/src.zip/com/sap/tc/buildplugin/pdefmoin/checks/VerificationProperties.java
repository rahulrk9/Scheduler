package com.sap.tc.buildplugin.pdefmoin.checks;

public class VerificationProperties
{
	public final static String	ALL_PRODUCTS		= "ALL_PRODUCTS";
	public final static String	ALL_PRODUCTS_YES	= "ALL_PRODUCTS_YES";
	public final static String	ALL_PRODUCTS_NO		= "ALL_PRODUCTS_NO";
	public final static String	PRODUCT_NAME		= "PRODUCT_NAME";
	public final static String	VENDOR				= "VENDOR";
	public final static String	VERSION				= "VERSION";
}
