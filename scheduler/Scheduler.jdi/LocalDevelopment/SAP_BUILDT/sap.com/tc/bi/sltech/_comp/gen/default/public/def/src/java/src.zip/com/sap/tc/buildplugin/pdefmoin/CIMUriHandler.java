package com.sap.tc.buildplugin.pdefmoin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.URIHandler;
import org.eclipse.emf.ecore.resource.impl.URIHandlerImpl;

import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IArchiveDescriptor;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pp.api.IDevelopmentComponent;

/**
 * {@link URIHandler} for CIM EMF resources.
 * 
 * @author d048997
 * @author d037595
 */
public class CIMUriHandler extends URIHandlerImpl implements URIHandler {

	public static final String CIM_SUFFIX = ".sldata";
	
	private final IPluginBuildInfo pbi;
	
	public CIMUriHandler() {
		this.pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
	}
	
	@Override
	public boolean exists(URI uri, Map<?, ?> options) {

		InputStream inp = null;
		try {
			inp = createInputStream(uri, options);
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (inp != null) {
				try { inp.close(); } catch (IOException e) { throw new RuntimeException(e);	}
			}
		}
	}
	
	@Override
	public InputStream createInputStream(URI uri, Map<?, ?> options) throws IOException {
		final _CIMUri cimUri = new _CIMUri(uri);

		IDevelopmentComponent currentDc = pbi.getCurrentDevelopmentComponent();

		if (isLocatedInCurrentDc(cimUri)) {
			// check the DC folders
			File f = new File(pbi.getRootDir().getAbsolutePath() + File.separator + cimUri.path);
			if (f.exists()) {
				return new FileInputStream(f);
			}
			// unable to load -> exception
			throw new FileNotFoundException("Unable to create input stream for URI " + uri
				+ ": File is not located in the relevant folders of DC " + currentDc);
			
		} else {
			// archives

			// find referenced archives
			List<String> arguments = Collections.emptyList();
			List<IArchiveDescriptor> archiveDescriptors = pbi.getArchiveDescriptors(pbi.getCompilationDirs(), arguments);
			boolean archiveDcFound = false;
			for (IArchiveDescriptor archiveDescriptor : archiveDescriptors) {
				// get archive dc
				IDevelopmentComponent archiveDc = pbi.getDevelopmentComponent(archiveDescriptor.getPublicPartReference());

				// check if dc in uri matches archive dc
				if (archiveDc.getName().equals(cimUri.dcName) && archiveDc.getVendor().equals(cimUri.dcVendor)) {
					archiveDcFound = true;
					
					// get relevant folders (valid for all the zips)
					List<String> relevantFolders = new ArrayList<String>();
					relevantFolders.addAll(archiveDc.getPackageFolders());
					relevantFolders.addAll(archiveDc.getSourceFolders());

					for (String relevantFolder : relevantFolders) {
						if (cimUri.path.startsWith("/" + relevantFolder)) {
							// relevant folder matches the one our uri starts with
							// -> trying to find the resource in all zips

							InputStream is = this.createStreamForArchiveDC(cimUri, archiveDescriptor);
							if (is != null) {
								return is;
							}
						}
					}
				}
			}
			if(archiveDcFound) {
				// found matching archive DC but could not locate uri in valid folders of the archive
				throw new FileNotFoundException("Unable to create input stream for URI " + uri
						+ ": Could not locate resource in archive DC vendor=" + cimUri.dcVendor + ", name=" + cimUri.dcName);
			} else {
				// could not find a DC matching the vendor+name in the given uri
				throw new FileNotFoundException("Unable to create input stream for URI " + uri + ": DC does not exist.");
			}
		}

	}

	/**
	 * Checks if the given URI points to a resource in the relevant folders of
	 * the currently built DC.
	 */
	private boolean isLocatedInCurrentDc(_CIMUri cimUri) {
		IDevelopmentComponent currentDc = pbi.getCurrentDevelopmentComponent();
		if (currentDc.getName().equals(cimUri.dcName) && currentDc.getVendor().equals(cimUri.dcVendor)) {
			// located in relevant folder?
			for (String relevantFolder : pbi.getDCDirs()) {
				if (cimUri.path.startsWith("/" + relevantFolder + "/")) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Returns an InputStream or null if it could not be opened for some reason.
	 */
	private InputStream createStreamForArchiveDC(_CIMUri cimUri, IArchiveDescriptor archiveDescriptor) {
		// get pp archives (zips) of the archive
		// (we don't know which one contains the resource we
		// are looking for)
		List<File> archiveFiles = archiveDescriptor.getFiles();
		for (File archiveFile : archiveFiles) {

			ZipFile zipFile = null;
			try {
				zipFile = new ZipFile(archiveFile);
				String entryName = null;
				if (cimUri.path.charAt(0) == '/') {
					entryName = cimUri.path.substring(1);
				} else {
					entryName = cimUri.path;
				}
				ZipEntry entry = zipFile.getEntry(entryName);

				if (entry != null) {
					// file exists in current archive, open stream
					InputStream is = zipFile.getInputStream(entry);
					if (is != null) {
						return new ZipFileInputStreamWrapper(zipFile, is);
					}
				}
				// failed to create input stream or entry was null
				zipFile.close();

			} catch (Exception e) {
				break; // error accessing current archive -> try the next one
			}
		}
		return null;
	}

	@Override
	public OutputStream createOutputStream(URI uri, Map<?, ?> options) throws IOException {
		throw new IOException(new UnsupportedOperationException("creating resource not allowed"));
	}

	@Override
	public void delete(URI uri, Map<?, ?> options) throws IOException {
		throw new IOException(new UnsupportedOperationException("deleting resource not allowed"));	}

	@Override
	public Map<String, ?> getAttributes(URI uri, Map<?, ?> options) {
		return super.getAttributes(uri, options);
	}

	private static class ZipFileInputStreamWrapper extends InputStream {
		private final ZipFile zipFile;
		private final InputStream wrappedInputStream;

		public ZipFileInputStreamWrapper(ZipFile zipFile, InputStream wrappedInputStream) {
			this.zipFile = zipFile;
			this.wrappedInputStream = wrappedInputStream;
		}

		@Override
		public void close() throws IOException {
			super.close();
			if (this.zipFile != null) {
				try {
					zipFile.close();
				} catch (Exception e) {
					// ignore
					Log.warn("close failed (ignored)",e);
				}
			}
		}

		// delegate methods
		public int read() throws IOException {
			return wrappedInputStream.read();
		}

		public int available() throws IOException {
			return wrappedInputStream.available();
		}

		public boolean equals(Object obj) {
			return wrappedInputStream.equals(obj);
		}

		public int hashCode() {
			return wrappedInputStream.hashCode();
		}

		public void mark(int readlimit) {
			wrappedInputStream.mark(readlimit);
		}

		public boolean markSupported() {
			return wrappedInputStream.markSupported();
		}

		public int read(byte[] b, int off, int len) throws IOException {
			return wrappedInputStream.read(b, off, len);
		}

		public int read(byte[] b) throws IOException {
			return wrappedInputStream.read(b);
		}

		public void reset() throws IOException {
			wrappedInputStream.reset();
		}

		public long skip(long n) throws IOException {
			return wrappedInputStream.skip(n);
		}

		public String toString() {
			return wrappedInputStream.toString();
		}
	}
	
	public static URI createCIMUri(String dcVendor, String dcName, String[] pathToResourceSegments) {
		return _CIMUri.createCIMUri(_CIMUri.mangleDcName(dcVendor, dcName), pathToResourceSegments);
	}
	
	public static URI createCIMUri(String dcVendor, String dcName, String path) {
		return _CIMUri.createCIMUri(dcVendor, dcName, path);
	}
	
	private static class _CIMUri {
		public String dcVendor;
		public String dcName;
		public String path;

		public _CIMUri(URI uri) {
			String woProt = uri.toString().substring(SCHEME_PREFIX.length());
			int indexOfSlash = woProt.indexOf("/");
			String tmp = woProt.substring(0, indexOfSlash);
			int i = tmp.indexOf('~');
			this.dcVendor = tmp.substring(0, i);
			this.dcName = tmp.substring(i + 1).replaceAll("~", "/");
			this.path = woProt.substring(indexOfSlash);
		}

		@Override
		public String toString() {
			return createCIMUri(dcVendor, dcName, path).toString();
		}
		
		private static URI createCIMUri(String dcVendor, String dcName, String path) {
			return createCIMUri(mangleDcName(dcVendor, dcName), extractPathSegments(path));
		}

		private static URI createCIMUri(String mangledDcVendorAndName, String[] pathToResourceSegments) {
			return URI.createHierarchicalURI(SCHEME, mangledDcVendorAndName, null, pathToResourceSegments, null, null);
		}

		private static String mangleDcName(String dcVendor, String dcName) {
			return dcVendor + "~" + dcName.replace("/", "~");
		}
		
		private static String[] extractPathSegments(String pathToResource) {
			StringTokenizer tok = new StringTokenizer(pathToResource, "/");
			int numberOfTokens = tok.countTokens();
			String[] segments = new String[numberOfTokens];
			for (int i = 0; tok.hasMoreElements(); i++) {
				segments[i] = tok.nextToken();
			}
			return segments;
		}
		
		private static final String SCHEME = "ox"; // CIM URIs use the ox schema
		private static final String SCHEME_PREFIX = SCHEME + "://";
	}

}
