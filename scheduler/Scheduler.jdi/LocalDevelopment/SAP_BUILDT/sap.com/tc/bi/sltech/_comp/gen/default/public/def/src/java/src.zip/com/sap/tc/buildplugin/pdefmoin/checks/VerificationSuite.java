package com.sap.tc.buildplugin.pdefmoin.checks;

import java.util.ArrayList;

import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * This class contains a list of verification classes. Each verification is executed in the order it was registered to the suite.
 */
public class VerificationSuite
{
	private final ArrayList<VerificationClass> verificationClasses;

	public VerificationSuite()
	{
		verificationClasses = new ArrayList<VerificationClass>();
	}

	/**
	 * Add new verification class to the suite
	 * @param checkClass - the verification class
	 */
	public void addVerificationClass(VerificationClass checkClass)
	{
		verificationClasses.add(checkClass);
	}

	/**
	 * Remove verification class from the suite
	 * @param checkClass - the verification class
	 */
	public void removeVerificationClass(VerificationClass checkClass)
	{
		verificationClasses.remove(checkClass);
	}

	/**
	 * Run all verifications in the order they were registered.
	 * @return - true if each verification was successful, otherwise returns false
	 * @throws BuildPluginException - thrown if a verification fails and the flag abortBuild is true for this verification
	 */
	public boolean verify() throws BuildPluginException
	{
		boolean checkOK = true;
		for (VerificationClass checkClass : verificationClasses)
		{
			boolean ok = checkClass.verify();
			if(!ok)
			{
				if(checkClass.abortBuild())
				{
					// abort build
					throw new BuildPluginException("Abort build because check failed - \"" + checkClass.getDescription() + "\".");
				}
				if(checkClass.stopOtherVerifications())
				{
					// stop all following verifications
					break;
				}
			}
			checkOK &= ok;
		}

		return checkOK;
	}
}
