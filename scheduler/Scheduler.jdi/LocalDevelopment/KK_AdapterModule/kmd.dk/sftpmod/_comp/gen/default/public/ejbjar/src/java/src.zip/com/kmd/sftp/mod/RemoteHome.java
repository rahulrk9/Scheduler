package com.kmd.sftp.mod;

import com.sap.aii.af.lib.mp.module.ModuleHome;

public @interface RemoteHome {

	Class<ModuleHome> value();

}
