package com.kmd.sftp.mod;

import com.sap.aii.af.lib.mp.module.ModuleLocalHome;



public @interface LocalHome {

	Class<ModuleLocalHome> value();

}
